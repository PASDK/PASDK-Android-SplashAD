package com.xender.adsdk.example.listener;

import android.util.Log;

import com.xender.ad.splash.AdEventListener;
import com.xender.ad.splash.PANative;
import com.xender.ad.splash.AdsVO;

public class MyPlainAdEventListener extends AdEventListener {

    @Override
    public void onReceiveAdSucceed() {
        showMsg("onReceiveAdSucceed");
    }

    @Override
    public void onReceiveAdVoSucceed(AdsVO result) {
        showMsg("onReceiveAdVoSucceed");
    }


    @Override
    public void onReceiveAdFailed(String result) {
        showMsg(result);
        Log.i("sdksample", "==error==" + result);
    }

    @Override
    public void onLandPageShown(PANative result) {
        showMsg("onLandPageShown");
    }

    @Override
    public void onShowSucceed(PANative result) {
        showMsg("onLandPageShown");
    }

    @Override
    public void onAdClicked(PANative result) {
        showMsg("onAdClicked");
    }

    @Override
    public void onAdClosed(PANative result) {
        showMsg("onAdClosed");
    }


    private void showMsg(String msg) {
        showToast(msg);
    }


    public static void showToast(String text) {
        // Toast.makeText(SampleApplication.context, text, Toast.LENGTH_SHORT).show();
    }

}
