package com.xender.adsdk.example;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.xender.adsdk.example.fragment.SplashAdFragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;

public class IndexAsListFragment extends Fragment {

    public static final LinkedHashMap<String, String> datas = new LinkedHashMap<>();


    static {
        datas.put("Element ads:  Open screen", SplashAdFragment.class.getCanonicalName());
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.listview_index, container, false);
        initView(rootView);
        return rootView;
    }


    public void initView(View rootView) {
        ListView listView = (ListView) rootView.findViewById(R.id.listView);

        String[] keyArray = new String[datas.size()];
        datas.keySet().toArray(keyArray);
        ArrayList<String> titleList = new ArrayList<>();
        Collections.addAll(titleList, keyArray);

        final MyArrayAdapter itemsAdapter =
                new MyArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, titleList);

        listView.setAdapter(itemsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                try {

                    Class t = Class.forName(datas.get(itemsAdapter.getItem(i)));
                    Object fragment = t.newInstance();
                    ((MainActivity) getActivity()).showFragment(
                            (android.support.v4.app.Fragment) fragment);

                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (java.lang.InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public static IndexAsListFragment getInstance() {
        IndexAsListFragment mainFragment = new IndexAsListFragment();
        return mainFragment;

    }


    public class MyArrayAdapter extends ArrayAdapter<String> {

        public MyArrayAdapter(Context context, int resource, ArrayList<String> objects) {
            super(context, resource, objects);
        }


        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            String data = getItem(position);
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(android.R.layout.simple_list_item_1, parent, false);
            }

            TextView tv = (TextView) convertView.findViewById(android.R.id.text1);
            tv.setText(data);

            return convertView;
        }
    }
}
