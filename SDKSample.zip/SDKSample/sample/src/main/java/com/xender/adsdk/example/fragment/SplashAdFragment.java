package com.xender.adsdk.example.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.xender.adsdk.example.R;
import com.xender.adsdk.example.SplashActivity;
import com.xender.adsdk.example.config.Config;
import com.xender.adsdk.example.listener.MyPlainAdEventListener;
import com.xender.ad.splash.PANative;
import com.xender.ad.splash.PlainAdSDK;

public class SplashAdFragment extends Fragment {

    private TextView adStatusTextView;
    private Button loadButton;

    private static final String TAG = "SplashAdFragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_open_screen, null);
        initView(view);
        return view;
    }


    private void initView(View view) {

        adStatusTextView = (TextView) view.findViewById(R.id.statusLabel);

        loadButton = (Button) view.findViewById(R.id.loadButton);
        loadButton.setText("LOAD AD");
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAd();
            }
        });

    }


    private void showAd() {
        log("Ready to load ads.");
        SplashActivity.showMe(getContext());
    }



    public void loadAd() {

        log("Splash Ad Loading...");
        // 预加载
        PlainAdSDK.preloadSplashAd(getContext(), Config.slotIdNative, new MyPlainAdEventListener() {
            @Override
            public void onReceiveAdSucceed() {
                log("OpenScreen Ad Loaded.");
            }

            @Override
            public void onReceiveAdFailed(String error) {
                if (error != null)
                    log("onReceiveAdFailed errorMsg=" + error);
            }

            @Override
            public void onAdClicked(PANative result) {

            }

            @Override
            public void onAdClosed(PANative result) {

            }
        });

    }


    private void log(final String s) {
        if (adStatusTextView != null) {
            Activity activity = getActivity();
            if (!isDetached() && activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adStatusTextView.setText(s);
                    }
                });
            }

        }
        Log.w(TAG, "log: " + s);
    }
}
